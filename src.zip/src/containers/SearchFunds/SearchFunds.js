import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'
import _ from 'lodash'
import { connect } from 'react-redux'
import { formValueSelector } from 'redux-form'
import {
  Card,
  CardFooter,
  CardHeader,
  CardTitle,
  FillContainer,
  ResultCount,
} from '@fc/react-playbook'

import s from './SearchFunds.scss'
import SearchFundsGrid from '../SearchFundsGrid'
import FlexColumnLayout from '../../components/FlexColumnLayout'
import Input from '../../components/Input'

const selector = formValueSelector('tradeOnBehalfOf')

const mapStateToProps = state => {
  const tradeOnBehalfOf = selector(state, 'tradeOnBehalfOf')
  return {
    tradeOnBehalfOf:
      typeof tradeOnBehalfOf === 'string' ? null : tradeOnBehalfOf,
  }
}

@connect(mapStateToProps)
class SearchFunds extends Component {
  static propTypes = {
    match: PropTypes.shape({
      url: PropTypes.string,
    }).isRequired,
    tradeOnBehalfOf: PropTypes.shape({
      id: PropTypes.string,
    }),
    title: PropTypes.node.isRequired,
    fundType: PropTypes.string.isRequired,
    accountType: PropTypes.string.isRequired,
  }

  static defaultProps = {
    tradeOnBehalfOf: null,
  }

  state = {
    account: null,
    totalCount: 0,
    displayCount: 0,
    search: '',
  }

  debounceSearch = _.debounce(e => {
    const search = e.target.value
    this.setState({
      search,
    })
  }, 300)

  onAccountChange = ({ account = null }) => {
    this.setState({ account })
  }

  onGridDataLoad = ({ totalCount, displayCount }) => {
    const {
      totalCount: currentTotalCount,
      displayCount: currentDisplayCount,
    } = this.state
    if (
      totalCount !== currentTotalCount ||
      displayCount !== currentDisplayCount
    ) {
      this.setState({
        totalCount,
        displayCount,
      })
    }
  }

  onSearch = e => {
    e.persist()
    this.debounceSearch(e)
  }

  render() {
    const { tradeOnBehalfOf, title, fundType, accountType } = this.props
    const { account, totalCount, displayCount, search } = this.state

    return (
      <FillContainer>
        <FlexColumnLayout>
          <Card className={cx(s.gridCard)}>
            <CardHeader>
              <CardTitle>{title}</CardTitle>
              <Input onChange={this.onSearch} />
            </CardHeader>
            <SearchFundsGrid
              id="search-funds-grid"
              variables={{
                institutionLocationId:
                  tradeOnBehalfOf && tradeOnBehalfOf.id
                    ? tradeOnBehalfOf.id
                    : null,
                accountIds: account ? [account.id] : [],
                fundType,
                accountType,
              }}
              tradeOnBehalfOf={tradeOnBehalfOf}
              account={account}
              fundType={fundType}
              accountType={accountType}
              onDataLoad={this.onGridDataLoad}
              search={search}
            />
            <CardFooter flexEnd>
              <ResultCount
                totalCount={totalCount}
                displayCount={displayCount}
              />
            </CardFooter>
          </Card>
        </FlexColumnLayout>
      </FillContainer>
    )
  }
}

export default SearchFunds
