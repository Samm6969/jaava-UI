import React, { Component } from 'react'
import PropTypes from 'prop-types'
import gql from 'graphql-tag'
import _ from 'lodash'

import Grid from '../../components/Grid'
import withQuery from '../../hoc/withQuery'

import columns from './TradeBlotterGridColumns'

const query = gql`
  query TradeBlotterGridQuery {
    viewer {
      recentOrders {
        id
        orderStatus
        orderId
        submitDate
        tradeDate
        fundAccount {
          fund {
            id
            name
          }
          account {
            name
          }
        }
        investorUid
        side
        quantity
        qtyDecimals
        currency {
          currencyCode
        }
        qtyType
        settlementDate
        cashSettlementStatus
        custodySettlementStatus
      }
    }
  }
`

// TODO: [NOT IN SPRINT] Use subscription to get real time trade data

// notes on subscription: One thing manages receiving new events (deltas), with an id and a new property value, then uses updater function to merge them into the store

@withQuery({
  query,
})
class TradeBlotterGrid extends Component {
  static propTypes = {
    id: PropTypes.string.isRequired,
    isLoading: PropTypes.bool,
    viewer: PropTypes.shape({
      recentOrders: PropTypes.arrayOf(
        PropTypes.shape({
          orderId: PropTypes.number.isRequired,
          orderStatus: PropTypes.string.isRequired,
        }),
      ),
    }),
    selectedStatus: PropTypes.string.isRequired,
    updateCounts: PropTypes.func.isRequired,
  }

  static defaultProps = {
    viewer: {
      recentOrders: [],
    },
  }

  state = {}

  constructor(props) {
    super(props)
    this.grid = React.createRef()
  }

  componentDidMount() {
    this.loadData(this.formatData())
  }

  componentDidUpdate(prevProps) {
    if (
      this.props.selectedStatus !== prevProps.selectedStatus ||
      this.props.viewer.recentOrders !== prevProps.viewer.recentOrders
    )
      this.loadData(this.formatData())
  }

  formatData = () => {
    const {
      viewer: { recentOrders = [] },
      selectedStatus,
      updateCounts,
    } = this.props
    const counts = {}

    const data = _.reduce(
      recentOrders,
      (acc, order) => {
        if (counts[order.orderStatus]) counts[order.orderStatus] += 1
        else counts[order.orderStatus] = 1
        if (selectedStatus === 'ALL' || selectedStatus === order.orderStatus) {
          acc.push({
            order,
            fund: order.fundAccount && order.fundAccount.fund,
          })
        }
        return acc
      },
      [],
    )

    updateCounts(counts)

    return { data }
  }

  loadData = ({ data }) => {
    const { isLoading } = this.props
    if (this.grid.current && !isLoading) {
      this.grid.current.loadData(data)
    }
  }

  render() {
    return (
      <Grid
        ref={this.grid}
        columns={columns}
        id={this.props.id}
        isLoading={this.props.isLoading}
      />
    )
  }
}

export default TradeBlotterGrid
