import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'
import _ from 'lodash'
import { connect } from 'react-redux'
import { formValueSelector } from 'redux-form'
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  FillContainer,
  LinkButton,
  ResultCount,
} from '@fc/react-playbook'

import s from './InvestmentOptions.scss'
import AccountSelector from '../AccountSelector'
import InvestmentOptionsGrid from '../InvestmentOptionsGrid'
import FlexColumnLayout from '../../components/FlexColumnLayout'
import Input from '../../components/Input'

const selector = formValueSelector('tradeOnBehalfOf')

const mapStateToProps = state => {
  const tradeOnBehalfOf = selector(state, 'tradeOnBehalfOf')
  return {
    tradeOnBehalfOf:
      typeof tradeOnBehalfOf === 'string' ? null : tradeOnBehalfOf,
  }
}

@connect(mapStateToProps)
class InvestmentOptions extends Component {
  static propTypes = {
    match: PropTypes.shape({
      url: PropTypes.string,
    }).isRequired,
    tradeOnBehalfOf: PropTypes.shape({
      id: PropTypes.string,
    }),
    title: PropTypes.node.isRequired,
    fundType: PropTypes.string.isRequired,
    accountType: PropTypes.string.isRequired,
  }

  static defaultProps = {
    tradeOnBehalfOf: null,
  }

  state = {
    account: null,
    selected: [],
    totalCount: 0,
    displayCount: 0,
    search: '',
  }

  debounceSearch = _.debounce(e => {
    const search = e.target.value
    this.setState({
      search,
    })
  }, 300)

  onAccountChange = ({ account = null }) => {
    this.setState({ account })
  }

  onGridDataLoad = ({ totalCount, displayCount }) => {
    const {
      totalCount: currentTotalCount,
      displayCount: currentDisplayCount,
    } = this.state
    if (
      totalCount !== currentTotalCount ||
      displayCount !== currentDisplayCount
    ) {
      this.setState({
        totalCount,
        displayCount,
      })
    }
  }

  getSelectedFundAccountIds = selected => {
    let accountIdList = []
    _.forEach(selected, fund => {
      const accounts = _.get(fund, 'accounts')
      const listOfIds = accounts.map(account => account.id)
      if (!_.isEmpty(listOfIds)) {
        accountIdList = accountIdList.concat(listOfIds)
      }
    })
    if (!_.isEmpty(accountIdList)) {
      accountIdList = _.uniq(accountIdList)
    }
    return accountIdList
  }

  onSelectionChanged = (selected, column) => {
    this.setState({
      selected: selected[column.id],
    })
  }

  onSearch = e => {
    e.persist()
    this.debounceSearch(e)
  }

  render() {
    const { match, tradeOnBehalfOf, title, fundType, accountType } = this.props
    const { account, selected, totalCount, displayCount, search } = this.state
    const selectedFundAccountIds = this.getSelectedFundAccountIds(selected)

    return (
      <FillContainer>
        <FlexColumnLayout>
          <Card>
            <CardContent className={s.selectorCardContent}>
              <AccountSelector
                variables={{
                  institutionLocationId:
                    tradeOnBehalfOf && tradeOnBehalfOf.id
                      ? tradeOnBehalfOf.id
                      : null,
                }}
                tradeOnBehalfOf={tradeOnBehalfOf}
                onChange={this.onAccountChange}
                accountType={accountType}
              />
            </CardContent>
          </Card>
          <Card className={cx(s.gridCard)}>
            <CardHeader>
              <CardTitle>{title}</CardTitle>
              <Input onChange={this.onSearch} />
            </CardHeader>
            <InvestmentOptionsGrid
              id="direct-investment-options-grid"
              variables={{
                institutionLocationId:
                  tradeOnBehalfOf && tradeOnBehalfOf.id
                    ? tradeOnBehalfOf.id
                    : null,
                accountIds: account ? [account.id] : [],
                fundType,
                accountType,
              }}
              tradeOnBehalfOf={tradeOnBehalfOf}
              account={account}
              onSelectionChanged={this.onSelectionChanged}
              onDataLoad={this.onGridDataLoad}
              search={search}
            />
            <CardFooter flexEnd>
              <ResultCount
                totalCount={totalCount}
                displayCount={displayCount}
              />
              <LinkButton
                primary
                to={{
                  pathname: `${match.url}/order-entry`,
                  state: {
                    selected,
                    fundAccountIds: selectedFundAccountIds,
                    accountType,
                  },
                }}
                disabled={!selected || selected.length === 0}
              >
                Trade Selected Funds
              </LinkButton>
            </CardFooter>
          </Card>
        </FlexColumnLayout>
      </FillContainer>
    )
  }
}

export default InvestmentOptions
