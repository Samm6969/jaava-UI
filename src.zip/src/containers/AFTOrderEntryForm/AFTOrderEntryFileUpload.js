import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@fc/react-playbook'
import gql from 'graphql-tag'
import { Mutation } from 'react-apollo'
import Button from '@fc/react-playbook/src/components/Button'

const uploadOrdersMutation = gql`
  mutation UploadAftOrders($file: Upload!) {
    uploadAftOrders(file: $file) {
      aftOrderResponsesId
      orderResponses {
        orderRequest {
          id
          accountNumber
          isin
          side
          quantityType
          amount
          currency
        }
        tradeInputValidationErrors {
          errorCode
          errorText
        }
      }
    }
  }
`

class AFTOrderEntryFileUpload extends Component {
  static propTypes = {
    title: PropTypes.string,
  }

  state = {
    selectedFileName: '',
    browseFileName: '',
  }

  onFileSelection(event) {
    console.log('~~~~~ onFileSelection ::> ', event.target.files[0], this.state)
    const fileObj = event.target.files[0]

    this.setState({
      selectedFileName: fileObj.name,
      file: fileObj,
    })
    console.log('~~~~~~~ Set after file upload ', this.state)
  }

  onOrderFileUploadComplete = response => {
    console.log('*** onOrderFileUploadComplete -->>> ', response)
  }

  onOrderFileUPloadMutationError = e => {
    console.error('*** onOrderConfirmMutationError -->>> ', e)
  }

  render() {
    const { title } = this.props
    return (
      <Mutation
        mutation={uploadOrdersMutation}
        variables={{
          file: this.state.file,
        }}
        onCompleted={this.onOrderFileUploadComplete}
        onError={this.onOrderFileUPloadMutationError}
      >
        {orderFileUploadMutation => (
          <Card>
            <CardHeader>
              <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent style={{ height: '60vh' }}>
              <div style={{ display: 'flex', marginTop: '1rem' }}>
                <input
                  type="text"
                  id="browseFileName"
                  name="browseFileName"
                  value={this.state.selectedFileName}
                  style={{ width: '100%' }}
                />
                <Button
                  onClick={() => document.getElementById('actFile').click()}
                >
                  Browse
                </Button>
              </div>
              <input
                type="file"
                style={{ display: 'none' }}
                id="actFile"
                name="actFile"
                onChange={event => this.onFileSelection(event)}
              />
            </CardContent>
            <CardFooter flexend>
              <Button primary onClick={orderFileUploadMutation}>
                Submit Orders
              </Button>
              <Button>Reset</Button>
              <Button>Download Sample File</Button>
              <Button onClick={this.returnToOrderEntry}>
                Back to Orders Entry
              </Button>
            </CardFooter>
          </Card>
        )}
      </Mutation>
    )
  }
}

export default AFTOrderEntryFileUpload
