import React, { Component } from 'react'
import PropTypes from 'prop-types'

import { Field } from 'redux-form'
import { CheckboxField, SelectField, InputField } from '../../fields'

class AFTOrderEntryFormFundGroup extends Component {
  static propTypes = {
    fields: PropTypes.shape(PropTypes.object),
    meta: PropTypes.shape(PropTypes.object),
    onQtyTypeChange: PropTypes.func,
    sideOptions: PropTypes.arrayOf(PropTypes.object),
    qtyTypeOptions: PropTypes.arrayOf(PropTypes.object),
    currencyUnitsOptions: PropTypes.arrayOf(PropTypes.object),
    currencyCashOptions: PropTypes.arrayOf(PropTypes.object),
  }

  state = {
    inFocus: false,
  }

  getDisplayName = entity => entity.displayName

  required = value => {
    if (this.state.inFocus && value) {
      return 'Required'
    }
    return undefined
  }

  maxLength = value => {
    const reg = /^[0-9]*(?:\.[0-9]{0,4})?$/
    if ((value && value.length > 16) || !reg.test(value)) {
      return undefined
    }
    return value
  }

  isinValidations = value => {
    const reg = /^[a-zA-Z][a-zA-Z][0-9]+$/
    if (value && value.length !== 12) {
      return 'First two characters must be strings & maximum 12 characters are allowed.'
    }
    if (!reg.test(value)) {
      return 'First two characters must be strings'
    }
    return undefined
  }

  onBlur = event => {
    console.log('~~~~~ onBlur ', event)
    this.setState({
      inFocus: false,
    })
  }

  onFocus = event => {
    console.log('~~~~~ onFocus ', event)
    this.setState({
      inFocus: true,
    })
  }

  render() {
    const isLoading = false
    const {
      fields,
      meta,
      sideOptions,
      qtyTypeOptions,
      currencyUnitsOptions,
      currencyCashOptions,
      ...rest
    } = this.props
    return (
      <div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-around',
          }}
        >
          {fields.getAll().length === 0 ? (
            <div>
              <h5>Please add at least one order entry.</h5>
            </div>
          ) : (
            ''
          )}
        </div>
        {fields.map((member, index) => {
          const row = fields.get(index)
          return (
            <div key={member} style={{ display: 'flex', marginTop: '1rem' }}>
              <div
                style={{ flex: 1, order: 1, width: '3%', padding: '0 0 0 5px' }}
              >
                <Field
                  name={`${member}.selected`}
                  type="checkbox"
                  component={CheckboxField}
                />
              </div>
              <div style={{ order: 3, width: '15%' }}>
                {this.props.accounts.length > 0 ? (
                  <Field
                    name={`${member}.accounts`}
                    {...rest}
                    options={this.props.accounts}
                    placeholder={isLoading ? 'Loading...' : 'All Accounts'}
                    isLoading={isLoading}
                    isClearable
                    component={SelectField}
                    disabled={!row.selected}
                  />
                ) : (
                  <Field
                    name={`${member}.accounts`}
                    placeholder="Account"
                    component={InputField}
                    validate={[this.required]}
                    disabled={!row.selected}
                  />
                )}
              </div>
              <div style={{ order: 3, width: '13%' }}>
                <Field
                  name={`${member}.isin`}
                  placeholder="ISIN"
                  component={InputField}
                  validate={[this.required, this.isinValidations]}
                  disabled={!row.selected}
                />
              </div>
              <div style={{ order: 3, width: '15%' }}>
                <Field
                  name={`${member}.side`}
                  options={sideOptions}
                  placeholder={isLoading ? 'Loading...' : 'Side'}
                  isLoading={isLoading}
                  validate={[this.required]}
                  isClearable
                  component={SelectField}
                  disabled={!row.selected}
                />
              </div>
              <div style={{ order: 3, width: '15%' }}>
                <Field
                  name={`${member}.qtyType`}
                  {...rest}
                  options={qtyTypeOptions}
                  onChange={this.props.onQtyTypeChange}
                  component={SelectField}
                  disabled={!row.selected}
                />
              </div>
              <div style={{ order: 3, width: '14%' }}>
                <Field
                  name={`${member}.amount`}
                  placeholder="Amount"
                  component={InputField}
                  validate={[this.required, this.maxLength]}
                  disabled={!row.selected}
                  onBlur={this.onBlur}
                  onFocus={this.onFocus}
                />
              </div>
              <div style={{ order: 3, width: '15%' }}>
                <Field
                  name={`${member}.currency`}
                  options={
                    fields.get(index).qtyType.value === 'U'
                      ? currencyUnitsOptions
                      : currencyCashOptions
                  }
                  component={SelectField}
                  validate={[this.required]}
                  disabled={!row.selected}
                />
              </div>
              <div style={{ order: 3, width: '10%' }}>
                <Field
                  name={`${member}.clientreference`}
                  placeholder="Client Reference"
                  component={InputField}
                  disabled={!row.selected}
                />
              </div>
            </div>
          )
        })}
      </div>
    )
  }
}
export default AFTOrderEntryFormFundGroup
