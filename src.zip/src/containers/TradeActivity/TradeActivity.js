import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'
import {
  Card,
  CardFooter,
  CardHeader,
  CardTitle,
  FillContainer,
  ResultCount,
} from '@fc/react-playbook'

import TradeActivityGrid from '../TradeActivityGrid'
import s from './TradeActivity.scss'
import FlexColumnLayout from '../../components/FlexColumnLayout'

class TradeActivity extends Component {
  static propTypes = {
    match: PropTypes.shape({
      url: PropTypes.string,
    }),
    title: PropTypes.node.isRequired,
  }

  state = {
    totalCount: 0,
    displayCount: 0,
  }

  onGridDataLoad = ({ totalCount, displayCount }) => {
    const {
      totalCount: currentTotalCount,
      displayCount: currentDisplayCount,
    } = this.state
    if (
      totalCount !== currentTotalCount ||
      displayCount !== currentDisplayCount
    ) {
      this.setState({
        totalCount,
        displayCount,
      })
    }
  }

  render() {
    const { title } = this.props
    const { totalCount, displayCount } = this.state

    return (
      <FillContainer>
        <FlexColumnLayout>
          <Card className={cx(s.gridCard)}>
            <CardHeader>
              <CardTitle>{title}</CardTitle>
            </CardHeader>
            <TradeActivityGrid onDataLoad={this.onGridDataLoad} />
            <CardFooter flexEnd>
              <ResultCount
                totalCount={totalCount}
                displayCount={displayCount}
              />
            </CardFooter>
          </Card>
        </FlexColumnLayout>
      </FillContainer>
    )
  }
}

export default TradeActivity
