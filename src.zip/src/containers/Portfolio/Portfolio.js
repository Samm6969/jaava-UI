import React, { Component } from 'react'
import _ from 'lodash'
import cx from 'classnames'
import { Card, FillContainer } from '@fc/react-playbook'
import ReactHighcharts from 'react-highcharts'
import FlexColumnLayout from '../../components/FlexColumnLayout'
// import PieChart from '../../components/Chart/PieChart'
import { pieColors } from './constants'
import fundData from './fundData'
import s from './Portfolio.scss'

class Portfolio extends Component {
  render() {
    const seriesDataByFund = _.get(fundData, 'series')
    const totalByFund = _.get(fundData, 'totalMarketValue')
    // const seriesDataByFundCat = _.get(fundCatData, 'series')
    // const totalByFundCat = _.get(fundCatData, 'totalMarketValue')

    const seriesByFundGraphData = []
    seriesDataByFund.map(item =>
      seriesByFundGraphData.push([item.longName, item.floatValue, item.name]),
    )

    const standardChartSubtitle = '( All Values in USD Equivalent )'
    const chartSubTitle = `<b>Total Market Value:</b> ${totalByFund} ${standardChartSubtitle}`

    const chartOptions = {
      chart: {
        credits: false,
      },
      title: {
        text: 'Market Value By Fund',
      },
      subtitle: {
        text: chartSubTitle,
        useHTML: true,
      },
      tooltip: {
        headerFormat: '',
        pointFormat: '{point.name}',
        style: {
          fontSize: '11px',
          fontWeight: 'bold',
        },
      },
      colors: pieColors,
      series: [
        {
          data: [...seriesByFundGraphData],
          keys: ['name', 'y', 'shortName'],
          type: 'pie',
        },
      ],
      legend: {
        align: 'right',
        verticalAlign: 'top',
        y: 100,
        layout: 'vertical',
        borderWidth: 1,
        itemStyle: {
          fontSize: '11px',
          fontWeight: 'normal',
        },
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          slicedOffset: 0,
          cursor: 'pointer',
          animation: true,
          dataLabels: {
            enabled: true,
            overflow: 'none',
            distance: 40,
            formatter() {
              return `<span style="font-size: 10px; font-weight: normal">'${
                this.point.shortName
              }: ${this.y} %</span>`
            },
          },
          showInLegend: !_.isEmpty(seriesByFundGraphData),
        },
      },
    }
    return (
      <FillContainer>
        <FlexColumnLayout>
          <Card className={cx(s.gridCard)}>
            <ReactHighcharts config={chartOptions} />
          </Card>
        </FlexColumnLayout>
      </FillContainer>
    )
  }
}

export default Portfolio
