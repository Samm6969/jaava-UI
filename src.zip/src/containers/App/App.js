import React, { Component, Fragment } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { DragDropContext } from 'react-dnd'
import HTML5Backend from 'react-dnd-html5-backend'
import { ApolloProvider } from 'react-apollo'
// eslint-disable-next-line import/no-extraneous-dependencies
import { hot } from 'react-hot-loader'
import {
  Header,
  Footer,
  RouteBuilder,
  RoutesProvider,
  RoutesConsumer,
  LegacyBrowserNotification,
  SecondaryNavigation,
  SidebarNavigation,
  PageNotFound,
  FillContainer,
  UIErrorBoundary,
  SessionTimeoutWarning,
  SessionProvider,
} from '@fc/react-playbook'

import UserDropdown from '../UserDropdown'

import Client from '../../ApolloClient'
import s from './App.scss'
import appRoutes from '../../routes'
import navLinks from '../../navLinks'
import Logout from '../../utils/Logout'
import TradeOnBehalfOfSelector from '../TradeOnBehalfOfSelector'

@withRouter
@DragDropContext(HTML5Backend)
@connect(({ environment, Settings }) => ({
  environment,
  Settings,
}))
class App extends Component {
  static propTypes = {
    environment: PropTypes.string,
  }

  render() {
    const { environment } = this.props
    const version = `v${process.env.VERSION}`

    return (
      <SessionProvider onLogout={Logout}>
        <ApolloProvider client={Client}>
          <RoutesProvider value={{ routes: appRoutes }}>
            <div className={s.root}>
              <LegacyBrowserNotification />
              <Header serviceName="Fund Connect" environment={environment}>
                <TradeOnBehalfOfSelector
                  initialValues={{ tradeOnBehalfOf: null }}
                />
                <UserDropdown />
              </Header>
              <SecondaryNavigation />
              <div className={s.layout}>
                <SidebarNavigation links={navLinks} />
                <RoutesConsumer>
                  {({ routes }) => (
                    <RouteBuilder
                      routes={routes}
                      pageNotFound={() => (
                        <FillContainer>
                          <PageNotFound />
                        </FillContainer>
                      )}
                      render={({
                        provider: Provider = Fragment,
                        component: RouteComponent,
                        ...rest
                      }) => (
                        <div className={s.page}>
                          <UIErrorBoundary>
                            <Provider>
                              <RouteComponent {...rest} />
                            </Provider>
                          </UIErrorBoundary>
                        </div>
                      )}
                    />
                  )}
                </RoutesConsumer>
              </div>
              <Footer version={version} />
            </div>
            <div id="portal" />
            <SessionTimeoutWarning />
          </RoutesProvider>
        </ApolloProvider>
      </SessionProvider>
    )
  }
}

export default hot(module)(App)

// export default App
