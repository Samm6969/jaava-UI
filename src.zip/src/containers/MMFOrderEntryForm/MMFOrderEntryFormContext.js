import { createContext } from 'react'

export const {
  Provider: MMFOrderEntryFormProvider,
  Consumer: MMFOrderEntryFormConsumer,
} = createContext({})
