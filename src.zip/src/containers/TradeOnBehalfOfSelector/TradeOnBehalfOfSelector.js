import React, { Component } from 'react'
import { reduxForm, Field } from 'redux-form'
import PropTypes from 'prop-types'
import gql from 'graphql-tag'

import s from './TradeOnBehalfOfSelector.scss'
import withQuery from '../../hoc/withQuery'
import { SelectField } from '../../fields'

const query = gql`
  query TradeOnBehalfOfSelectorQuery {
    viewer {
      institutionLocations {
        id
        self
        location {
          name
        }
        institution {
          name
        }
      }
    }
  }
`
@withQuery({
  query,
})
@reduxForm({
  form: 'tradeOnBehalfOf',
})
class TradeOnBehalfOfSelector extends Component {
  static propTypes = {
    handleSubmit: PropTypes.func,
    isLoading: PropTypes.bool,
    viewer: PropTypes.shape({
      institutionLocations: PropTypes.arrayOf(
        PropTypes.shape({
          id: PropTypes.string.isRequired,
          location: PropTypes.shape({
            name: PropTypes.string.isRequired,
          }).isRequired,
          institution: PropTypes.shape({
            name: PropTypes.string.isRequired,
          }).isRequired,
        }),
      ),
    }),
  }

  static defaultProps = {
    viewer: { institutionLocations: [] },
  }

  state = {
    initialValue: null,
  }

  // static getDerivedStateFromProps(nextProps, prevState) {
  //   const {
  //     form,
  //     isLoading,
  //     dispatch,
  //     viewer: { institutionLocations },
  //   } = nextProps
  //
  //   const { initialValue } = prevState
  //
  //   if (isLoading) {
  //     return {
  //       initialValue: null,
  //     }
  //   } else if (
  //     !initialValue &&
  //     !isLoading &&
  //     institutionLocations.length !== 0
  //   ) {
  //     let nextInitialValue = _.find(institutionLocations, { self: true })
  //     if (!nextInitialValue) {
  //       // eslint-disable-next-line prefer-destructuring
  //       nextInitialValue = institutionLocations[0]
  //     }
  //     dispatch(
  //       initialize(form, {
  //         tradeOnBehalfOf: nextInitialValue,
  //       }),
  //     )
  //     // console.log(initialize(form, nextInitialValue))
  //     return {
  //       initialValue: nextInitialValue,
  //     }
  //   }
  //
  //   return null
  // }

  renderOptionLabel = ({ location, institution, self }) => {
    const label = `${location.name}.${institution.name}`
    if (self) {
      return <strong>{label} (Default)</strong>
    }
    return label
  }

  render() {
    const {
      handleSubmit,
      isLoading,
      viewer: { institutionLocations },
    } = this.props
    const { initialValue } = this.state

    if (!isLoading && institutionLocations.length === 1) {
      return null
    }

    return (
      <form onSubmit={handleSubmit} className={s.form}>
        <Field
          name="tradeOnBehalfOf"
          label="Act for"
          showDelimiter
          inline
          isLoading={isLoading}
          options={institutionLocations}
          defaultValue={initialValue}
          placeholder={isLoading ? 'Loading...' : 'All Institutions'}
          isClearable
          getOptionLabel={this.renderOptionLabel}
          getOptionValue={({ id }) => id}
          component={SelectField}
        />
      </form>
    )
  }
}

export default TradeOnBehalfOfSelector
