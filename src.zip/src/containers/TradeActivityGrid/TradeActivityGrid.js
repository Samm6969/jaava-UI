import React, { Component } from 'react'
import PropTypes from 'prop-types'
import gql from 'graphql-tag'
import _ from 'lodash'

import withQuery from '../../hoc/withQuery'
import Grid from '../../components/Grid'

import columns from './TradeActivityGridColumns'

const query = gql`
  query TradeActivityGridQuery {
    viewer {
      searchOrders {
        id
        orderStatus
        orderId
        submitDate
        tradeDate
        redemptionFeeType
        redemptionFee
        totalShares
        settlementAmt
        fundAccount {
          providerAccountNumber
          fund {
            id
            name
            longName
            cusip
            isin
            iso
            sedol
            ticker
            provider {
              name
            }
            statistics {
              latestPrice
            }
          }
          account {
            name
            division {
              name
            }
            client {
              name
            }
            tradeInstitution {
              location {
                name
              }
              institution {
                name
              }
            }
          }
        }
        investorUid
        side
        quantity
        qtyDecimals
        currency {
          currencyCode
        }
        qtyType
        settlementDate
        cashSettlementStatus
        custodySettlementStatus
        quantity
        cashInstruction {
          name
          custodianName
          custodianAccount
          custodianBIC
          cashCutoffTimeDisplay
        }
        custodyInstruction {
          name
          custodianName
          custodianAccount
          custodianBIC
        }
      }
    }
  }
`

@withQuery({
  query,
})
class TradeActivityGrid extends Component {
  static propTypes = {
    isLoading: PropTypes.bool,
    viewer: PropTypes.shape({
      searchOrders: PropTypes.arrayOf(
        PropTypes.shape({
          orderId: PropTypes.number.isRequired,
          orderStatus: PropTypes.string.isRequired,
        }),
      ),
    }),
    title: PropTypes.string,
  }

  static defaultProps = {
    viewer: {
      fundAccountsForInstitution: [],
    },
  }

  constructor(props) {
    super(props)
    this.grid = React.createRef()
  }

  state = {}

  componentDidMount() {
    this.loadData()
  }

  componentDidUpdate() {
    this.loadData()
  }

  static getDerivedStateFromProps(props) {
    const data = _.map(props.viewer.searchOrders, order => ({
      order,
      fund: order.fundAccount && order.fundAccount.fund,
    }))
    return { data }
  }

  loadData = () => {
    const { isLoading, onDataLoad } = this.props
    if (this.grid.current && !isLoading) {
      const { data } = this.state
      this.grid.current.loadData(data)

      if (typeof onDataLoad === 'function') {
        onDataLoad({
          data,
          totalCount: data.length,
          displayCount: data.length,
        })
      }
    }
  }

  render() {
    return <Grid ref={this.grid} columns={columns} {...this.props} />
  }
}

export default TradeActivityGrid
