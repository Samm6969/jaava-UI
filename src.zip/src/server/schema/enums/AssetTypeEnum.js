import { createEnum } from '../schemaHelpers'

export default createEnum('AssetTypeEnum', {
  MMFETF: {},
  AFT: {},
  MF: {},
  TD: {},
})
