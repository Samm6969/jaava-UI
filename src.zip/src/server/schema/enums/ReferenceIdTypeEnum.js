import { createEnum } from '../schemaHelpers'

export default createEnum('ReferenceIdTypeEnum', {
  BLOOMBERG: {},
  SSGA: {},
  SWIFT_FIN: {},
  CASH_SWEEP: {},
})
