import { createEnum } from '../schemaHelpers'

export default createEnum('AutoSettlementModelEnum', {
  REGISTERED: {},
  PLATFORM: {},
})
