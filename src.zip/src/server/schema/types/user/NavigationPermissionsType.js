import { GraphQLBoolean } from 'graphql'

import { createType } from '../../schemaHelpers'

const NavigationPermissionsType = {
  name: 'NavigationPermissions',
  fields: {
    dashboard: {
      type: GraphQLBoolean,
    },
    portfolio: {
      type: GraphQLBoolean,
    },
    searchFunds: {
      type: GraphQLBoolean,
    },
    accessShortTerm: {
      type: GraphQLBoolean,
    },
    accessLongTerm: {
      type: GraphQLBoolean,
    },
    accessNonDirect: {
      type: GraphQLBoolean,
    },
    accessETF: {
      type: GraphQLBoolean,
    },
    accessETFBloombergBasket: {
      type: GraphQLBoolean,
    },
    accessAFT: {
      type: GraphQLBoolean,
    },
    accessTradeBlotter: {
      type: GraphQLBoolean,
    },
    tradeActivityReport: {
      type: GraphQLBoolean,
    },
    fundStatisticsReport: {
      type: GraphQLBoolean,
    },
    intradayPricesReport: {
      type: GraphQLBoolean,
    },
    holdingsReport: {
      type: GraphQLBoolean,
    },
    accountSummaryReport: {
      type: GraphQLBoolean,
    },
    transparencyConnect: {
      type: GraphQLBoolean,
    },
    manager: {
      type: GraphQLBoolean,
    },
    settlementInstructions: {
      type: GraphQLBoolean,
    },
    emailNotifications: {
      type: GraphQLBoolean,
    },
    capitalAdvisorsRatings: {
      type: GraphQLBoolean,
    },
    preferences: {
      type: GraphQLBoolean,
    },
  },
}

export default createType(NavigationPermissionsType)
