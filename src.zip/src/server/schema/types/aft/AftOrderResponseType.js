import { GraphQLList, GraphQLInt } from 'graphql'
import { createType } from '../../schemaHelpers'
import AftOrderRequestType from './AftOrderRequestType'
import FCErrorType from '../order/FCErrorType'
import OrderStatusEnum from '../../enums/OrderStatusEnum'

const AftOrderResponseType = {
  name: 'AftOrderResponse',
  fields: {
    orderRequest: {
      type: AftOrderRequestType,
    },
    orderId: {
      type: GraphQLInt,
    },
    orderStatus: {
      type: OrderStatusEnum,
    },
    tradeInputValidationErrors: {
      type: GraphQLList(FCErrorType),
    },
  },
}
export default createType(AftOrderResponseType)
