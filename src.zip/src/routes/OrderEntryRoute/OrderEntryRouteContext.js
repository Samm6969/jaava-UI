import { createContext } from 'react'

export const {
  Provider: OrderEntryProvider,
  Consumer: OrderEntryConsumer,
} = createContext({})
