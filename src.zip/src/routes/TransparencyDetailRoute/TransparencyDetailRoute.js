import React, { Component } from 'react'
import PropTypes from 'prop-types'

class TransparencyDetailRoute extends Component {
  static propTypes = {
    match: PropTypes.shape({
      params: PropTypes.shape({
        fundId: PropTypes.string,
        name: PropTypes.string,
      }).isRequired,
    }).isRequired,
  }

  render() {
    const { match } = this.props
    return (
      <div variables={{ id: match.params.fundId }}>
        Transparency Detail Page - {match.params.name}
      </div>
    )
  }
}

export default TransparencyDetailRoute
