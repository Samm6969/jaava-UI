import React from 'react'
import { Legal, ScrollContainer, Support } from '@fc/react-playbook'
import { ACCOUNT_TYPES, FUND_TYPES } from '../enums'

import OrderEntryRoute from './OrderEntryRoute'
import DashboardRoute from './DashboardRoute'
import FundDetailsRoute from './FundDetailsRoute'
import InvestmentOptionsRoute from './InvestmentOptionsRoute'
import SearchFundsRoute from './SearchFundsRoute'
import BloombergBSKTRoute from './BloombergBSKTRoute'
import TradeBlotterRoute from './TradeBlotterRoute'
import TradeActivityRoute from './TradeActivityRoute'

import AgentFundTradingRoute from './AgentFundTradingRoute'
import PortfolioRoute from './PortfolioRoute'
import ExtJSGridRoute from './ExtJSGridRoute'

const SearchFunds = SearchFundsRoute({
  title: 'Search Short Term Funds',
  fundType: FUND_TYPES.SHORT_TERM,
  accountType: ACCOUNT_TYPES.FULLY_DISCLOSED,
})

const ShortTermFunds = InvestmentOptionsRoute({
  title: 'Short Term Funds',
  fundType: FUND_TYPES.SHORT_TERM,
  accountType: ACCOUNT_TYPES.FULLY_DISCLOSED,
})

const LongTermFunds = InvestmentOptionsRoute({
  title: 'Long Term Funds',
  fundType: FUND_TYPES.LONG_TERM,
  accountType: ACCOUNT_TYPES.FULLY_DISCLOSED,
})

const NonDirect = InvestmentOptionsRoute({
  title: 'Non-Direct',
  fundType: FUND_TYPES.SHORT_TERM,
  accountType: ACCOUNT_TYPES.OMNI,
})

const AgentFundTrading = AgentFundTradingRoute({
  title: 'Enter Order',
})

const TradeActivity = TradeActivityRoute({ title: 'Trade Activity' })

const orderEntry = [
  {
    path: '/order-entry',
    title: 'Order Entry',
    component: OrderEntryRoute,
  },
]

const portfolio = PortfolioRoute({ title: 'Portfolio Chart' })

export default [
  {
    path: '/',
    title: 'Dashboard',
    component: DashboardRoute,
  },
  {
    path: '/funds/search',
    title: 'Search Funds',
    component: SearchFunds,
  },
  {
    path: '/trade/direct/short-term',
    title: 'Investment Options',
    component: ShortTermFunds,
    routes: [...orderEntry],
  },
  {
    path: '/trade/direct/long-term',
    title: 'Investment Options',
    component: LongTermFunds,
    routes: [...orderEntry],
  },
  {
    path: '/trade/non-direct/short-term',
    title: 'Investment Options',
    component: NonDirect,
    routes: [...orderEntry],
  },
  {
    path: '/trade/agent-fund-trading',
    title: 'Agent Fund Trading | Enter Order',
    component: AgentFundTrading,
  },
  {
    path: '/trade/blotter',
    title: 'Trade Blotter',
    component: TradeBlotterRoute,
  },
  {
    path: '/trade/bloomberg-bskt',
    title: 'Bloomberg BSKT',
    component: BloombergBSKTRoute,
  },
  {
    path: '/fund-details/:id',
    title: 'Fund Details',
    component: FundDetailsRoute,
    routes: [...orderEntry],
  },
  {
    path: '/reports/trade-activity',
    title: 'Trade Activity',
    component: TradeActivity,
  },
  {
    path: '/extjs',
    title: 'Ext JS Grid Example',
    component: ExtJSGridRoute,
  },
  {
    path: '/portfolio',
    title: 'Portfolio',
    component: portfolio,
  },
  {
    path: '/legal',
    title: 'Legal',
    component: () => (
      <ScrollContainer>
        <Legal />
      </ScrollContainer>
    ),
  },
  {
    path: '/support',
    title: 'Support',
    component: () => (
      <ScrollContainer>
        <Support />
      </ScrollContainer>
    ),
  },
]
