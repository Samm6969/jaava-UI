import React from 'react'

export default value => <div>Evan {value}</div>
