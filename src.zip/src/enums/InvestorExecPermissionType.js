export default {
  REQUIRE_APPROVAL: 'EXEC WITH APPROVE',
  EXEC: 'EXEC',
}
