export default {
  FULL: 'FULL',
  ROUND: 'ROUND',
}
