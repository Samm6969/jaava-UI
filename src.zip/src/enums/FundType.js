export default {
  SHORT_TERM: 'SHORT_TERM',
  LONG_TERM: 'LONG_TERM',
}
