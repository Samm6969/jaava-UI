export default {
  SAME_DAY: 1,
  NEXT_DAY: 2,
}
