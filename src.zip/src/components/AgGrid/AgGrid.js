import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { AgGridReact } from 'ag-grid-react'

import './AgGrid.scss'
import { AgGridProvider, AgGridConsumer } from './AgGridContext'
import { columnsPropType } from './agGridPropTypes'

class AgGrid extends Component {
  static propTypes = {
    onGridReady: PropTypes.func,
    loading: PropTypes.bool,
    columnDefs: columnsPropType,
  }

  componentDidUpdate() {
    this.handleLoadingOverlay()
  }

  onGridReady = (...args) => {
    const { onGridReady } = this.props
    if (typeof onGridReady === 'function') {
      onGridReady(...args)
    }

    const [agGrid] = args

    this.gridApi = agGrid.api
    this.gridColumnApi = agGrid.columnApi

    this.handleLoadingOverlay()
  }

  handleLoadingOverlay = () => {
    const { loading } = this.props
    if (this.gridApi) {
      if (loading) {
        this.gridApi.showLoadingOverlay()
      } else {
        this.gridApi.hideOverlay()
      }
    }
  }

  render() {
    const { columnDefs, ...props } = this.props

    console.log(props)

    return (
      <div
        className="ag-theme-balham"
        style={{ flex: 1 }}
        // Enables hot module reloading for grid
        key={module.hot ? Date.now() : undefined}
      >
        <AgGridConsumer>
          {({ id, columns }) => (
            <AgGridReact
              id={id}
              enableColResize
              rowHeight={32}
              {...props}
              // reactNext
              columnDefs={columnDefs || columns}
              onGridReady={this.onGridReady}
            />
          )}
        </AgGridConsumer>
      </div>
    )
  }
}

export { AgGridProvider, AgGridConsumer, AgGrid }
