import { createContext } from 'react'

export const { Provider: MenuProvider, Consumer: MenuConsumer } = createContext(
  {},
)
