import React, { Component } from 'react'
// import PropTypes from 'prop-types'

import s from './MenuSpacer.scss'

class MenuSpacer extends Component {
  render() {
    return <div className={s.spacer} />
  }
}

export default MenuSpacer
