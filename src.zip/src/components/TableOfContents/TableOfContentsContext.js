import { createContext } from 'react'

export const {
  Provider: TableOfContentsProvider,
  Consumer: TableOfContentsConsumer,
} = createContext({})
