import { createContext } from 'react'

export const {
  Provider: CheckColumnProvider,
  Consumer: CheckColumnConsumer,
} = createContext({})
