import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'

import s from './GridCell.scss'

class GridCell extends PureComponent {
  static propTypes = {
    children: PropTypes.node,
    className: PropTypes.string,
    innerCellProps: PropTypes.shape({
      className: PropTypes.string,
    }),
  }

  static defaultProps = {
    innerCellProps: {
      className: '',
    },
  }

  render() {
    const { children, className, innerCellProps, ...rest } = this.props
    const { className: innerClassName, ...restInner } = innerCellProps
    return (
      <div className={cx(s.cell, className)} {...rest}>
        <div>
          <div className={cx(s.innerCell, innerClassName)} {...restInner}>
            {children}
          </div>
        </div>
      </div>
    )
  }
}

export default GridCell
