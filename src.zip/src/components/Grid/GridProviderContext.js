import { createContext } from 'react'

export const { Provider: GridProvider, Consumer: GridConsumer } = createContext(
  {},
)
