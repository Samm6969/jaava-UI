import { ApolloClient } from 'apollo-client'
import { InMemoryCache } from 'apollo-cache-inmemory'
import { HttpLink } from 'apollo-link-http'
import { onError } from 'apollo-link-error'
import { ApolloLink } from 'apollo-link'

// eslint-disable-next-line import/prefer-default-export
export const Client = new ApolloClient({
  link: ApolloLink.from([
    onError(({ graphQLErrors, networkError }) => {
      if (graphQLErrors) {
        // TODO: Production quality logging
        // eslint-disable-next-line no-console
        console.group('[GraphQL Error(s)]')
        graphQLErrors.map(({ message, locations, path }) =>
          // eslint-disable-next-line no-console
          console.log(
            `Message: ${message}, Location: ${locations}, Path: ${path}`,
          ),
        )
      }
      // eslint-disable-next-line no-console
      if (networkError) console.log(`[Network error]: ${networkError}`)
    }),
    new HttpLink({
      uri: process.env.API_ENDPOINT,
      credentials: 'same-origin',
    }),
  ]),
  cache: new InMemoryCache(),
})
