import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'

import s from './OrderStatusColumnRenderer.scss'

// TODO: Should render the status and a corresponding color
// TODO: Ask for clarification on what status maps to what color

class OrderStatusColumnRenderer extends Component {
  static propTypes = {
    value: PropTypes.string.isRequired,
    className: PropTypes.string,
  }

  render() {
    const { className, value } = this.props

    const isRejected = value === 'REJECTED'

    return (
      <div className={cx({ [`${s.rejected}`]: isRejected }, className)}>
        {value}
      </div>
    )
  }
}

export default OrderStatusColumnRenderer
