import { commitMutation as commitMutationReactRelay } from 'react-relay'
import {
  setNetworkErrorsAction,
  setNetworkSuccessMessageAction,
} from '@fc/react-playbook'
import environment from '../environment'
import { getStore } from '../store'

async function commitMutation(config) {
  return new Promise((resolve, reject) => {
    commitMutationReactRelay(environment, {
      ...config,
      onError: error => reject(error),
      onCompleted: (response, errors) => {
        if (errors && errors.length > 0) {
          reject(errors)
        } else resolve(response)
      },
    })
  })
    .then(res => {
      const { successMessage, onCompleted } = config
      if (successMessage) {
        const message =
          typeof successMessage === 'function'
            ? successMessage(res)
            : successMessage
        getStore().dispatch(setNetworkSuccessMessageAction(message))
      }
      if (typeof onCompleted === 'function') {
        onCompleted(res)
      }
    })
    .catch(rawErrs => {
      const { onError } = config
      let errors = [
        'An error occurred. Please try again later or contact our help desk',
      ]
      if (rawErrs) {
        errors = Array.isArray(rawErrs) ? rawErrs : [rawErrs]
      }
      errors = errors.map(err => (typeof err === 'object' ? err.message : err))

      getStore().dispatch(setNetworkErrorsAction(errors))
      if (typeof onError === 'function') {
        onError(errors)
      }
      throw errors
    })
}

export default commitMutation
