// eslint-disable-next-line
export const dummyData = [
  {
    id: 1,
    name: 'Net',
    isDefault: true,
  },
  {
    id: 2,
    name: 'Gross',
  },
]
