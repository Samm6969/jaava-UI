// eslint-disable-next-line
export const dummyCashData = [
  {
    id: 3,
    name: 'Multi Acc / Cash USD (MULTI)',
    detail: [
      { label: 'SSI Custodian Name', value: 'cust name' },
      { label: 'SSI Custodian Account', value: 'ZYLYGL390K' },
      { label: 'SSI Custodian BIC', value: 'ZYLYGL390K' },
    ],
  },
  {
    id: 4,
    name: 'Test Cash Test Case 4172',
    detail: [
      { label: 'SSI Custodian Name', value: 'cust name custcash' },
      { label: 'SSI Custodian Account', value: 'ZYLYGL390K333333' },
      { label: 'SSI Custodian BIC', value: 'ZYLYGL390K11111113' },
    ],
  },
]
