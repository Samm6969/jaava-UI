// eslint-disable-next-line
export const dummyCustodyData = [
  {
    id: 1,
    name: 'Place of Safekeeping Optional B (Multi)',
    detail: [
      { label: 'SSI Custodian Name', value: 'cust name' },
      { label: 'SSI Custodian Account', value: 'ZYLYGL390K' },
      { label: 'SSI Custodian BIC', value: 'ZYLYGL390K' },
    ],
  },
  {
    id: 2,
    name: 'Test Custi Multi Currency SSI Name Field (Multi)',
    detail: [
      { label: 'SSI Custodian Name', value: 'cust name custody' },
      { label: 'SSI Custodian Account', value: 'ZYLYGL390K11111' },
      { label: 'SSI Custodian BIC', value: 'ZYLYGL390K111112' },
    ],
  },
]
