// Identity loader
module.exports = function() {
  return 'export function reactify(target) {return function(){return null}}; export function reactify2(target) {return function(){return null}}; export function renderWhenReady(){return function(){return null}}; global.renderWhenReady = function(){return function(){return null}}'
}
