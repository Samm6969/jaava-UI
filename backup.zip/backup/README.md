### Gettings Started
1. Install the latest LTS version of [Node.js LTS](https://nodejs.org/en/). NOT the Current Version(Latest Features)
2. Check you have the latest version of node and npm install
    ```
    node -v
    npm -v
    ```
3. Copy ```.env.prod``` to ```.env```
4. Edit the API_SERVER variable in ```.env``` to point to your local fund connect Tomcat server. **Only include the host and port with no trailing slashes or quotes**
    ```
    PORT=9092
    DEV_PORT=3001
    API_SERVER=http://localhost:9081
    FC_ENV=dev
    APP_NAME=INV
    APP_URI=/fundconnect/api/fndc/inv
    # BASENAME=/fundconnect/inv
    API_ENDPOINT=/graphql
    ```
5. Run the following commands
    ```
    npm install
    npm watch
    ```
6. Add the userid parameter to your localhost url e.g. [http://localhost:8000/?userid=bos.democorp.investor01](http://localhost:3001/?userId=bos.democorp.investor01)
