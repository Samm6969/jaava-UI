module.exports = {
  parser: 'babel-eslint',
  extends: [
    'airbnb',
    'prettier',
    'prettier/react',
    'plugin:css-modules/recommended',
  ],
  plugins: ['compat', 'css-modules', 'prettier'],
  env: {
    jest: true,
    browser: true,
    node: true,
  },
  globals: {
    renderer: true,
    mount: true,
    Ext: true,
  },
  rules: {
    'react/destructuring-assignment': 'off',
    'react/forbid-foreign-prop-types': 'off',
    'jsx-a11y/anchor-is-valid': 'off',
    'linebreak-style': 'off',
    'jsx-a11y/click-events-have-key-events': 'off',
    'jsx-a11y/no-static-element-interactions': 'off',
    'jsx-a11y/no-noninteractive-tabindex': 'off',
    'react/require-default-props': 'off',
    // We automatically convert pure class to function for production
    // babel-plugin-transform-react-pure-class-to-function
    'react/prefer-stateless-function': 'off',
    // Allow .js files to use JSX syntax
    // https://github.com/yannickcr/eslint-plugin-react/blob/master/docs/rules/jsx-filename-extension.md
    'react/jsx-filename-extension': ['error', { extensions: ['.js', '.jsx'] }],
    // ESLint plugin for prettier formatting
    // https://github.com/prettier/eslint-plugin-prettier
    'prettier/prettier': 'error',
    'import/no-extraneous-dependencies': [
      'error',
      {
        packageDir: './',
      },
    ],
    'jsx-a11y/label-has-for': [
      2,
      {
        components: [],
        required: {
          every: ['id'],
        },
        allowChildren: false,
      },
    ],
    'no-plusplus': ['error', { allowForLoopAfterthoughts: true }],
  },
}
