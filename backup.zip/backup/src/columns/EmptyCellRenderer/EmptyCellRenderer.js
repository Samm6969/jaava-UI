import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RightAlignCell from '../../components/RightAlignCell'

class EmptyCellRenderer extends Component {
  static propTypes = {
    rightAlign: PropTypes.bool,
    emptyCellText: PropTypes.node,
  }

  static defaultProps = {
    emptyCellText: '--',
  }

  render() {
    const { rightAlign, emptyCellText } = this.props
    if (rightAlign) {
      return <RightAlignCell>{emptyCellText}</RightAlignCell>
    }
    return emptyCellText
  }
}

export default EmptyCellRenderer
