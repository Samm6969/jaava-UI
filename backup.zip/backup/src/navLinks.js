export default [
  {
    exact: true,
    to: '/',
    label: 'Dashboard',
  },
  {
    to: '/portfolio',
    label: 'Portfolio',
  },
  {
    to: '/funds/search',
    label: 'Search Funds',
  },
  {
    group: 'Trade',
    to: '/trade',
    collapsible: true,
    items: [
      {
        to: '/direct/short-term',
        label: 'Short Term Funds',
      },
      {
        to: '/direct/long-term',
        label: 'Long Term Funds',
      },
      {
        to: '/non-direct/short-term',
        label: 'Non-Direct',
      },
      {
        to: '/etf',
        label: 'ETFs',
      },
      {
        to: '/bloomberg-bskt',
        label: 'Bloomberg BSKT',
      },
      {
        to: '/agent-fund-trading',
        label: 'Agent Fund Trading',
      },
      {
        to: '/blotter',
        label: 'Trade Blotter',
      },
    ],
  },
  {
    group: 'Reports',
    to: '/reports',
    collapsible: true,
    items: [
      {
        to: '/trade-activity',
        label: 'Trade Activity',
      },
      {
        to: '/fund-statistics',
        label: 'Fund Statistics',
      },
      {
        to: '/intraday-prices',
        label: 'Intraday Prices',
      },
      {
        to: '/holdings-report',
        label: 'Holdings Report',
      },
      {
        to: '/account-summary',
        label: 'Account Summary',
      },
    ],
  },
  {
    group: 'Transparency',
    to: '/transparency',
    collapsible: true,
    items: [
      {
        to: '/details',
        label: 'Details',
      },
      {
        to: '/chart',
        label: 'Chart',
      },
      {
        to: '/virtual-portfolio',
        label: 'Virtual Portfolio',
      },
    ],
  },
  {
    group: 'Administration',
    to: '/admin',
    collapsible: true,
    items: [
      {
        to: '/manager',
        label: 'Manager',
        items: [
          {
            to: '/order-limits',
            label: 'Investor Order Limits',
          },
          {
            to: '/fund-limits',
            label: 'Fund Limits',
          },
          {
            to: '/order-notifications',
            label: 'Order Notifications',
          },
        ],
      },
      {
        to: '/settlement-instructions',
        label: 'Settlement Instructions',
      },
      {
        to: '/email-notificatioins',
        label: 'Email Notifications',
      },
      {
        to: '/preferences',
        label: 'Preferences',
      },
    ],
  },
]
