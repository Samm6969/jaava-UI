import React, { Fragment, PureComponent } from 'react'
import { LoadingIndicator } from '@fc/react-playbook'
import ReactResizeDetector from 'react-resize-detector'
import PropTypes from 'prop-types'
import _ from 'lodash'
import { Grid as GridWindow, ScrollSync } from 'react-virtualized'

import s from './Grid.scss'
import GridHeader from './GridHeader'
// import GridWindow from './GridWindow'
import GridCell from './GridCell'
import { CheckColumnProvider, CheckColumnConumer } from './CheckColumnContext'
import { isUndefinedNull } from '../../utils/utils'
import CheckColumn from './CheckColumn'

class Grid extends PureComponent {
  static propTypes = {
    id: PropTypes.string.isRequired,
    width: PropTypes.number,
    height: PropTypes.number,
    rowHeight: PropTypes.number,
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string,
        dataIndex: PropTypes.string,
        // eslint-disable-next-line
        text(props, propName, componentName) {
          if (typeof props.xtype === 'string' && props.xtype !== 'column') {
            return PropTypes.checkPropTypes(
              { text: PropTypes.node },
              props,
              propName,
              componentName,
            )
          }
          return PropTypes.checkPropTypes(
            { text: PropTypes.node.isRequired },
            props,
            propName,
            componentName,
          )
        },
        renderer: PropTypes.func,
      }),
    ).isRequired,
    // eslint-disable-next-line react/forbid-prop-types
    data: PropTypes.array,
    isLoading: PropTypes.bool,
    emptyCellText: PropTypes.node,
    onSelectionChanged: PropTypes.func,
    onSelect: PropTypes.func,
    onDeselect: PropTypes.func,
  }

  static defaultProps = {
    rowHeight: 40,
    emptyCellText: '--',
  }

  recordIdProp = Symbol('recordId')

  constructor(props) {
    super(props)
    this.node = React.createRef()
    const { width, height } = this.props
    this.state.width = width
    this.state.height = height
  }

  state = {
    renderedColumns: [],
    selected: {},
    data: [],
  }

  onResizeGrid = (fillWidth, fillHeight) => {
    const { width, height } = this.props
    this.setState({
      width: width || fillWidth,
      height: height || fillHeight,
    })
  }

  onResizeScrollWindow = (fillWidth, fillHeight) => {
    this.setState({
      scrollWindowWidth: fillWidth,
      scrollWindowHeight: fillHeight,
    })
  }

  onHeaderRender = nextRenderedColumns => {
    const { renderedColumns } = this.state
    if (renderedColumns.length === 0) {
      this.setState({
        renderedColumns: nextRenderedColumns,
      })
    }
  }

  onSelectionChanged = ({ column, record }) => {
    const { onSelectionChanged } = this.props
    if (typeof onSelectionChanged === 'function') {
      const { selected } = this.state
      onSelectionChanged(selected, column, record)
    }
  }

  onSelect = ({ column, record }) => {
    const { onSelect } = this.props

    if (typeof onSelect === 'function') {
      onSelect(record, column)
    }

    const { id } = column
    this.setState(
      ({ selected }) => {
        let currentSelection = selected[id] || []
        if (!record) {
          const { data } = this.state
          currentSelection = [...data]
        } else {
          currentSelection.push(record)
        }
        return {
          selected: {
            ...selected,
            [id]: currentSelection,
          },
        }
      },
      () => {
        this.onSelectionChanged({ column, record })
      },
    )
  }

  onDeselect = ({ column, record }) => {
    const { onDeselect } = this.props
    if (typeof onDeselect === 'function') {
      onDeselect(column, record)
    }

    const { id } = column
    this.setState(
      ({ selected }) => {
        let currentSelection = selected[id] || []
        if (record) {
          // eslint-disable-next-line no-underscore-dangle
          _.remove(currentSelection, selection => selection._id === record._id)
        } else {
          currentSelection = []
        }
        return {
          selected: {
            ...selected,
            [id]: currentSelection,
          },
        }
      },
      () => {
        this.onSelectionChanged({ column, record })
      },
    )
  }

  getColumnWidth = ({ index, columnIndex }) => {
    if (typeof document === 'undefined') {
      return 'auto'
    }

    const { renderedColumns } = this.state
    // eslint-disable-next-line
    const column =
      renderedColumns[typeof columnIndex !== 'undefined' ? columnIndex : index]
    if (!column) {
      // console.log(column, index, props, args)
      return 100
    }
    const node = document.getElementById(column.id)

    return node.offsetWidth
  }

  getRowHeight = () => {
    const { rowHeight } = this.props
    return rowHeight
  }

  loadData = (data = []) => {
    this.setState({
      data: data.map((record, index) => ({
        ...record,
        _id: `record-${index}`,
      })),
    })
  }

  defaultRenderer = value => {
    const { emptyCellText } = this.props
    if (typeof value === 'object' || isUndefinedNull(value)) {
      return emptyCellText
    }
    return value
  }

  cellRenderer = ({ columnIndex, rowIndex, style, key }) => {
    const { renderedColumns, data } = this.state
    if (data.length === 0) {
      return null
    }
    const column = renderedColumns[columnIndex]
    const { dataIndex, renderer: ColumnRenderer, xtype } = column
    const record = data[rowIndex]
    const value = _.get(record, dataIndex)

    return (
      <GridCell key={key} style={style}>
        {xtype === 'column' &&
          typeof ColumnRenderer === 'function' && (
            <ColumnRenderer
              value={value}
              record={record}
              dataIndex={dataIndex}
              column={column}
              columnIndex={columnIndex}
            />
          )}
        {xtype === 'column' &&
          typeof ColumnRenderer !== 'function' &&
          this.defaultRenderer(value)}
        {xtype === 'checkcolumn' && (
          <CheckColumnConumer>
            {props => (
              <CheckColumn
                value={value}
                record={record}
                dataIndex={dataIndex}
                column={column}
                columnIndex={columnIndex}
                {...props}
              />
            )}
          </CheckColumnConumer>
        )}
      </GridCell>
    )
  }

  render() {
    const { id, columns, rowHeight, isLoading } = this.props
    const {
      renderedColumns,
      selected,
      data,
      width,
      height,
      scrollWindowWidth,
      scrollWindowHeight,
    } = this.state
    const hasData = data.length !== 0
    const headerRendered = renderedColumns.length !== 0
    const style = {
      width,
      height,
    }
    return (
      <Fragment>
        <ReactResizeDetector
          handleWidth
          handleHeight
          onResize={this.onResizeGrid}
        />
        <CheckColumnProvider
          value={{
            onSelectionChanged: this.onSelectionChanged,
            onSelect: this.onSelect,
            onDeselect: this.onDeselect,
            selected,
            totalCount: data.length,
          }}
        >
          <ScrollSync>
            {({ onScroll, scrollLeft }) => (
              <div id={id} ref={this.node} style={style} className={s.grid}>
                <GridHeader
                  columns={columns}
                  rowHeight={rowHeight}
                  rendered={this.onHeaderRender}
                  scrollLeft={scrollLeft}
                />
                <div className={s.body}>
                  <ReactResizeDetector
                    handleWidth
                    handleHeight
                    onResize={this.onResizeScrollWindow}
                  />
                  {headerRendered &&
                    hasData && (
                      <GridWindow
                        width={scrollWindowWidth}
                        height={scrollWindowHeight}
                        cellRenderer={this.cellRenderer}
                        columnWidth={this.getColumnWidth}
                        columnCount={renderedColumns.length}
                        rowHeight={this.getRowHeight}
                        rowCount={data.length}
                        onScroll={onScroll}
                      />
                    )}
                  {isLoading && <LoadingIndicator />}
                </div>
              </div>
            )}
          </ScrollSync>
        </CheckColumnProvider>
      </Fragment>
    )
  }
}

export default Grid
