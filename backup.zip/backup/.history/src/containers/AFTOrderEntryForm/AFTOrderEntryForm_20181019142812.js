import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
  LoadingIndicator,
} from '@fc/react-playbook'
import Button from '@fc/react-playbook/src/components/Button'
import gql from 'graphql-tag'
import { Mutation } from 'react-apollo'
import _ from 'lodash'
import { connect } from 'react-redux'
import {
  Field,
  FieldArray,
  reduxForm,
  formValueSelector,
  change,
} from 'redux-form'
import s from './AFTOrderEntryForm.scss'
import AFTOrderEntryFormFundGroup from './AFTOrderEntryFormFundGroup'
import { CheckboxField } from '../../fields'
import withQuery from '../../hoc/withQuery'

const formAFTOrderEntry = formValueSelector('AFTOrderEntry')

const pages = {
  AFT_ORDER_ENTRY: 'AFT_ORDER_ENTRY',
  AFT_ORDER_CONFIRMATION: 'AFT_ORDER_CONFIRMATION',
}

const query = gql`
  query ATFOrderEntryFormQuery {
    viewer {
      aftAccountNumbers
    }
    currencies {
      id
      currencyId
      currencyCode
      name
    }
  }
`
// eslint-disable-next-line no-unused-vars
const EnterAftOrders = gql`
  mutation EnterAftOrders($input: AftOrderRequestsInput!) {
    enterAftOrders(input: $input) {
      id
      orderResponses {
        id
        orderRequest {
          id
          accountNumber
          isin
          side
          quantityType
          amount
          currency
          message
        }
        tradeInputValidationErrors {
          errorCode
          errorText
        }
      }
    }
  }
`
const ConfirmAftOrdersMutation = gql`
  mutation ConfirmAftOrders($input: AftOrderRequestsInput!) {
    enterAftOrders(input: $input) {
      id
      orderResponses {
        id
        orderRequest {
          id
          accountNumber
          isin
          side
          quantityType
          amount
          currency
          message
        }
        tradeInputValidationErrors {
          errorCode
          errorText
        }
      }
    }
  }
`

function mapStateToProps(state) {
  const orderEntries = [
    {
      selected: false,
      qtyType: { value: 'U', label: 'Units' },
      currency: { value: 'Fund CCY', label: 'Fund CCY' },
    },
  ]
  const selectAll = false
  const initialValues = {
    selectAll,
    orderEntries,
  }
  return {
    initialValues,
    selectAll: formAFTOrderEntry(state, 'selectAll'),
    orderEntries: formAFTOrderEntry(state, 'orderEntries'),
  }
}

function mapDispatchToProps(dispatch) {
  return {
    // onSubmit(values) {},
    updateOrderEntriesState(key, val) {
      dispatch(change('AFTOrderEntry', key, val))
    },
  }
}
const validate = values => {
  const errors = {}
  if (!values.orderEntries || !values.orderEntries.length) {
    errors.orderEntries = { _error: 'At least one order must be selected' }
  } else {
    const membersArrayErrors = []
    errors.orderEntries = { _error: undefined }
    values.orderEntries.forEach((member, memberIndex) => {
      const memberErrors = {}
      if (!member.accounts) {
        memberErrors.accounts = 'Required'
        membersArrayErrors[memberIndex] = memberErrors
      }
    })

    if (membersArrayErrors.length) {
      errors.orderEntries = membersArrayErrors
    }
  }
  // console.log('End::::~~~~~~~~~~~~ >>> validate <===> errors ', errors)
  return errors
}
@connect(
  mapStateToProps,
  mapDispatchToProps,
)
@reduxForm({
  form: 'AFTOrderEntry',
  validate,
})
@withQuery({
  query,
})
class AFTOrderEntryForm extends Component {
  static propTypes = {
    handleSubmit: PropTypes.func,
    isLoading: PropTypes.bool,
    submitting: PropTypes.bool,
    title: PropTypes.string,
    updateOrderEntriesState: PropTypes.func,
    viewer: PropTypes.shape({
      aftAccountNumbers: PropTypes.arrayOf(PropTypes.string),
    }),
    orderEntries: PropTypes.arrayOf(PropTypes.object),
  }

  state = {
    page: pages.AFT_ORDER_ENTRY,
    orderEntries: [],
    noOfSelectedOrders: 0,
    selectAll: false,
    accounts: [],
    sideOptions: [
      { value: 'S', label: 'Subscription' },
      { value: 'R', label: 'Redemption' },
    ],
    qtyTypeOptions: [
      { value: 'U', label: 'Units' },
      { value: 'C', label: 'Cash' },
    ],
    currencyUnitsOptions: [
      { value: 'Fund CCY', label: 'Fund CCY' },
      { value: 'EUR', label: 'EUR' },
    ],
    currencyCashOptions: [],
  }

  static getDerivedStateFromProps(props, state) {
    console.log(props)
    const accounts = []
    let currencyCashOptions = []
    let orderEntriesRef = state.orderEntries
    if (props.viewer) {
      _.forEach(props.viewer.aftAccountNumbers, entity => {
        accounts.push({ value: entity, label: entity })
      })
    }
    if (props.currencies) {
      currencyCashOptions = props.currencies.map(entity => ({
        value: entity.currencyId,
        label: entity.currencyCode,
      }))
    }
    if (orderEntriesRef.length === 0) {
      orderEntriesRef = props.initialValues.orderEntries
    }
    return {
      orderEntries: orderEntriesRef,
      accounts,
      currencyCashOptions,
    }
  }

  getSelectedOrdersCount = () => {
    const { orderEntries } = this.props
    const noOfSelectedOrders = orderEntries.filter(order => !order.selected)
      .length
    console.log(noOfSelectedOrders)
    setTimeout(() => {
      this.setState({ noOfSelectedOrders })
    }, 500)
  }

  onSelectAllFieldChange = (event, newValue) => {
    const { orderEntries } = this.props

    for (let i = 0; i < orderEntries.length; i++) {
      this.props.updateOrderEntriesState(
        `orderEntries[${i}].selected`,
        newValue,
      )
    }
    this.getSelectedOrdersCount()
  }

  addNewOrderEntry = () => {
    const { orderEntries } = this.props
    const { selectAll } = this.state
    orderEntries.push({
      selected: selectAll,
      qtyType: { value: 'U', label: 'Units' },
      currency: { value: 'Fund CCY', label: 'Fund CCY' },
    })
    this.props.updateOrderEntriesState('orderEntries', orderEntries)
    this.getSelectedOrdersCount()
  }

  removeSelectedOrderEntry = () => {
    const { orderEntries } = this.props
    _.remove(orderEntries, item => item.selected)
    this.props.updateOrderEntriesState('orderEntries', orderEntries)
    this.props.updateOrderEntriesState('selectAll', false)
    this.getSelectedOrdersCount()
  }

  setCurrencyByQtyType = (qtyTypeValue, selectedRowIndex) => {
    const { orderEntries } = this.props
    orderEntries[selectedRowIndex].currency = undefined
    this.props.updateOrderEntriesState('orderEntries', orderEntries)
  }

  // eslint-disable-next-line no-unused-vars
  onQtyTypeChange = (event, newValue, previousValue, name) => {
    const selectedRowIndex = parseInt(name.match(/\d+/)[0], 10)
    // this.props.updateOrderEntriesState(
    //   `orderEntries[${selectedRowIndex}].currency`,
    //   null,
    // )
    const { orderEntries } = this.props
    orderEntries[selectedRowIndex] = newValue
    this.props.updateOrderEntriesState('orderEntries', orderEntries)
    this.props.updateOrderEntriesState('selectAll', false)
    this.getSelectedOrdersCount()
  }

  onOrderSelectionChange = () => {
    this.getSelectedOrdersCount()
  }

  onSubmit = commitMutation => async values => {
    const filteredOrderEntries = values.orderEntries
      .filter(order => order.selected)
      .map(order => ({
        accountNumber: order.accounts.value || order.accounts,
        isin: order.isin,
        side: order.side.value,
        quantityType: order.qtyType.value,
        currency: order.currency.value,
        amount: order.amount,
        clientReferenceNumber: order.clientreference,
      }))

    const input = {
      aftOrderRequests: filteredOrderEntries,
    }
    console.log(input)
    const { data } = await commitMutation({
      variables: {
        input,
      },
    })
    const { orderResponses } = data.enterAftOrders
    if (orderResponses) {
      console.log(orderResponses)
    }

    if (!orderResponses) {
      this.setState({
        page: pages.AFT_ORDER_CONFIRMATION,
        orderEntries: values.orderEntries,
      })
    }
  }

  returnToOrderEntry = () => {
    this.setState({
      page: pages.AFT_ORDER_ENTRY,
    })
  }

  goToConfirmation = () => {
    this.setState({
      page: pages.AFT_ORDER_CONFIRMATION,
    })
  }
  // TODO: read Props.isLoading and do something

  onEnterAftOrdersError = e => {
    // eslint-disable-next-line no-console
    console.error(e)
  }

  // eslint-disable-next-line no-unused-vars
  createOnSubmit = commitMutation => async () => {
    const { orderEntries } = this.state
    const filteredOrderEntries = orderEntries
      .filter(order => order.selected)
      .map(order => ({
        accountNumber: order.accounts.value || order.accounts,
        isin: order.isin,
        side: order.side.value,
        quantityType: order.accounts,
        currency: order.currency.value,
        amount: order.amount,
        clientReferenceNumber: order.clientreference,
      }))

    const input = {
      aftOrderRequests: filteredOrderEntries,
    }

    const { data } = await commitMutation({
      variables: {
        input,
      },
    })

    console.log(filteredOrderEntries, data)
  }

  renderHeader = () => (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        overflowX: 'auto',
        overflowY: 'auto',
      }}
    >
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1, order: 1, width: '3%' }}>
          <Field
            name="selectAll"
            type="checkbox"
            onChange={this.onSelectAllFieldChange}
            value={this.state.selectAll}
            component={CheckboxField}
          />
        </div>
        <div className={s.heading} style={{ order: 2, width: '15%' }}>
          Account Number
        </div>
        <div className={s.heading} style={{ order: 3, width: '13%' }}>
          ISIN
        </div>
        <div className={s.heading} style={{ order: 3, width: '15%' }}>
          Side
        </div>
        <div className={s.heading} style={{ order: 3, width: '15%' }}>
          Qty Type
        </div>
        <div className={s.heading} style={{ order: 3, width: '14%' }}>
          Amount
        </div>
        <div className={s.heading} style={{ order: 3, width: '15%' }}>
          Currency
        </div>
        <div className={s.heading} style={{ order: 3, width: '10%' }}>
          Client Reference
        </div>
      </div>
    </div>
  )

  render() {
    // if(this.props.isLoading) return <h1>Loading</h1>
    const { handleSubmit, title, isLoading, submitting } = this.props
    const {
      page,
      orderEntries,
      sideOptions,
      qtyTypeOptions,
      currencyUnitsOptions,
      currencyCashOptions,
    } = this.state
    return (
      <Mutation
        mutation={ConfirmAftOrdersMutation}
        onError={this.onEnterAftOrdersError}
      >
        {(commitOrderEntryFormMutation, { loading: mutationLoading }) => {
          // eslint-disable-next-line no-unused-vars
          const loading = isLoading || submitting || mutationLoading
          const confirmMutation = this.onSubmit(commitOrderEntryFormMutation)
          return (
            <form
              onSubmit={handleSubmit(confirmMutation)}
              style={{ width: '100%' }}
            >
              {page === pages.AFT_ORDER_ENTRY && (
                <Card className={s.card}>
                  <CardHeader>
                    <CardTitle>{title}</CardTitle>
                  </CardHeader>
                  <CardContent style={{ height: '60vh' }}>
                    {loading && <LoadingIndicator />}
                    {!loading && (
                      <div>
                        {this.renderHeader()}
                        <FieldArray
                          name="orderEntries"
                          component={AFTOrderEntryFormFundGroup}
                          sideOptions={sideOptions}
                          qtyTypeOptions={qtyTypeOptions}
                          currencyUnitsOptions={currencyUnitsOptions}
                          currencyCashOptions={currencyCashOptions}
                          onQtyTypeChange={this.onQtyTypeChange}
                          onOrderSelectionChange={this.onOrderSelectionChange}
                          accounts={this.state.accounts}
                        />
                      </div>
                    )}
                  </CardContent>
                  <CardFooter flexEnd>
                    <Button
                      primary
                      type="submit"
                      disabled={this.state.noOfSelectedOrders === 0}
                    >
                      Enter Selected Orders{' '}
                      {this.state.noOfSelectedOrders > 0
                        ? this.state.noOfSelectedOrders
                        : ''}
                    </Button>
                    <Button onClick={this.addNewOrderEntry}>
                      Add More Orders
                    </Button>
                    <Button onClick={this.removeSelectedOrderEntry}>
                      Remove Selected Orders
                    </Button>
                    <Button>Clear Form</Button>
                    <Button>Upload Orders</Button>
                  </CardFooter>
                </Card>
              )}
              {page === pages.AFT_ORDER_CONFIRMATION && (
                <Card className={s.card}>
                  <CardHeader>
                    <CardTitle>{title}</CardTitle>
                  </CardHeader>
                  <CardContent style={{ height: '60vh' }}>
                    {this.renderHeader()}
                    {orderEntries.map(orderEntry => (
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          overflowX: 'auto',
                          overflowY: 'auto',
                        }}
                      >
                        <div style={{ display: 'flex' }}>
                          <div style={{ flex: 1, order: 1, width: '3%' }}>
                            <Field
                              name="selectAll"
                              type="checkbox"
                              onChange={this.onSelectAllFieldChange}
                              value={this.state.selectAll}
                              component={CheckboxField}
                            />
                          </div>
                          <div style={{ order: 2, width: '15%' }}>
                            {orderEntry.accounts.label || orderEntry.accounts}
                          </div>
                          <div style={{ order: 3, width: '13%' }}>
                            {orderEntry.isin}
                          </div>
                          <div style={{ order: 3, width: '15%' }}>
                            {orderEntry.side.label}
                          </div>
                          <div style={{ order: 3, width: '15%' }}>
                            {orderEntry.qtyType.label}
                          </div>
                          <div style={{ order: 3, width: '14%' }}>
                            {orderEntry.amount}
                          </div>
                          <div style={{ order: 3, width: '15%' }}>
                            {orderEntry.currency.label}
                          </div>
                          <div style={{ order: 3, width: '10%' }}>
                            {orderEntry.clientreference}
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                  <CardFooter flexEnd>
                    <Button primary>Confirm Orders</Button>

                    <Button onClick={this.removeSelectedOrderEntry}>
                      Remove Selected Orders
                    </Button>

                    <Button onClick={this.returnToOrderEntry}>
                      Return to Orders Entry
                    </Button>
                  </CardFooter>
                </Card>
              )}
            </form>
          )
        }}
      </Mutation>
    )
  }
}

export default AFTOrderEntryForm
