import React, { Component } from 'react'
import PropTypes from 'prop-types'

import { Field } from 'redux-form'
import { CheckboxField, SelectField, InputField } from '../../fields'

class AFTOrderEntryFormFundGroup extends Component {
  static propTypes = {
    fields: PropTypes.shape(PropTypes.object),
    meta: PropTypes.shape(PropTypes.object),
    onQtyTypeChange: PropTypes.func,
    sideOptions: PropTypes.arrayOf(PropTypes.object),
    qtyTypeOptions: PropTypes.arrayOf(PropTypes.object),
    currencyUnitsOptions: PropTypes.arrayOf(PropTypes.object),
    currencyCashOptions: PropTypes.arrayOf(PropTypes.object),
  }

  getDisplayName = entity => entity.displayName

  required = (value, orderEntries, index) => {
    console.log('Required Validation ', value, orderEntries, index)
    return value ? undefined : 'Required'
  }
  // getKey = index => index

  render() {
    const isLoading = false
    const {
      fields,
      meta,
      sideOptions,
      qtyTypeOptions,
      currencyUnitsOptions,
      currencyCashOptions,
      ...rest
    } = this.props
    return (
      <div>
        <div
          style={{
            borderTop: '1px solid gray',
            display: 'flex',
            justifyContent: 'space-around',
          }}
        >
          {fields.getAll().length === 0 ? (
            <div>
              <h5>Please add at least one order entry.</h5>
            </div>
          ) : (
            ''
          )}
        </div>
        {fields.map((member, index) => (
          <div key={member} style={{ display: 'flex', marginTop: '1rem' }}>
            <div style={{ flex: 1, order: 1, width: '3%' }}>
              <Field
                name={`${member}.selected`}
                type="checkbox"
                component={CheckboxField}
              />
            </div>
            <div style={{ order: 3, width: '15%' }}>
              {this.props.accounts.length > 0 ? (
                <Field
                  name={`${member}.accounts`}
                  {...rest}
                  options={this.props.accounts}
                  placeholder={isLoading ? 'Loading...' : 'All Accounts'}
                  isLoading={isLoading}
                  isClearable
                  component={SelectField}
                />
              ) : (
                <Field
                  name={`${member}.accounts`}
                  placeholder="Account"
                  component={InputField}
                  validate={[this.required]}
                />
              )}
            </div>
            <div style={{ order: 3, width: '13%' }}>
              <Field
                name={`${member}.isin`}
                placeholder="ISIN"
                component={InputField}
                validate={[this.required]}
              />
            </div>
            <div style={{ order: 3, width: '15%' }}>
              <Field
                name={`${member}.side`}
                options={sideOptions}
                placeholder={isLoading ? 'Loading...' : 'Side'}
                isLoading={isLoading}
                validate={[this.required]}
                isClearable
                component={SelectField}
              />
            </div>
            <div style={{ order: 3, width: '15%' }}>
              <Field
                name={`${member}.qtyType`}
                {...rest}
                options={qtyTypeOptions}
                onChange={this.props.onQtyTypeChange}
                component={SelectField}
              />
            </div>
            <div style={{ order: 3, width: '14%' }}>
              <Field
                name={`${member}.amount`}
                placeholder="Amount"
                component={InputField}
                validate={[
                  (value, values) => this.required(value, values, index),
                ]}
              />
            </div>
            <div style={{ order: 3, width: '15%' }}>
              <Field
                name={`${member}.currency`}
                options={
                  fields.get(index).qtyType.value === 'U'
                    ? currencyUnitsOptions
                    : currencyCashOptions
                }
                component={SelectField}
                validate={[
                  (value, values) => this.required(value, values, index),
                ]}
              />
            </div>
            <div style={{ order: 3, width: '10%' }}>
              <Field
                name={`${member}.clientreference`}
                placeholder="Client Reference"
                component={InputField}
              />
            </div>
          </div>
        ))}
      </div>
    )
  }
}
export default AFTOrderEntryFormFundGroup
